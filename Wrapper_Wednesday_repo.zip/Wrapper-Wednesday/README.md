# Wrapper Wednesday

**Own the agent, don't become one.**

This repository is the open source companion to the Wrapper Wednesday series on LinkedIn. Each month the series documents a freight technology company marketing "proprietary AI" that is, on inspection, a thin layer on somebody else's model. Each installment here rebuilds that product in public, free, under an MIT license, using the same publicly available tools the company itself uses.

If a Series A can rent it, so can you.

## The Field Reports

| No. | Company Covered | Codename | Stack | Status |
|-----|-----------------|----------|-------|--------|
| 1 | FleetWorks | **Wrapper Paul** | Vapi + Twilio + a frontier model | Released. See `/wrapper_paul` |
| 2 | CloneOps.ai | TBD | "Third Party AI Platforms" (their words, their Terms of Service) | Coming soon |
| 3 | Vooma | TBD | Prompt engineering on rented models | Coming soon |
| 4 | DataTruck | TBD | Azure OpenAI + LangChain | Coming soon |
| 5 | Sola | own_the_agent | AWS Textract + DSPy + Claude API + Modal | Released separately |

## Who is Wrapper Paul

Paul is a voice agent for freight. He comes in two configurations.

**Broker Paul** makes outbound calls. He sources capacity, negotiates rates up to your ceiling and never a dollar past it, and runs check calls without complaining about the fourth one before 9am.

**Carrier Paul** answers inbound calls. He quotes your trucks, negotiates down to your floor and never a dollar past it, and books freight while your dispatcher handles the loads that actually need a human.

Someday Broker Paul will call Carrier Paul and two config files will settle a rate on a Tuesday night. You are welcome to be the first to make that happen.

Full setup instructions live in [`/wrapper_paul`](./wrapper_paul).

## Ground rules

1. Everything here is built on publicly available, commercially licensed tools and public documentation. No proprietary code from any covered company appears in this repository, because after extensive review we were unable to locate any.
2. Every claim in the series is sourced from public materials: job postings, Terms of Service, GitHub accounts, vendor testimonials, and press releases.
3. This is educational. Before making automated outbound calls, read the compliance section in each installment. Consent and call recording laws are real and Paul respects them.
4. The tools themselves (Vapi, Twilio, the model providers) are excellent. That is the point. The tools are so good that the wrapper is the least valuable part of the invoice.

## Not affiliated

This project is not affiliated with, endorsed by, or connected to FleetWorks or any company covered in the series. All trademarks belong to their owners. Functionality is recreated from public documentation of publicly available platforms.

## Want this without maintaining it

If you want purpose engineered AI on a private instance, where your call data trains nobody's model but your own, that is what we build at [E3 Group](https://e3group.ai). Email **neverwrapped@e3group.ai**.

MIT licensed. Fork responsibly.

"""
Shared plumbing for creating Paul on Vapi.

One HTTP POST creates an assistant. That is the entire "platform build."
If the schema drifts, docs.vapi.ai is the source of truth.
"""

import os
from pathlib import Path

import requests
from dotenv import load_dotenv

load_dotenv()

VAPI_BASE = "https://api.vapi.ai"
API_KEY = os.getenv("VAPI_API_KEY", "")
SERVER_URL = os.getenv("SERVER_URL", "").rstrip("/")
COMPANY_NAME = os.getenv("COMPANY_NAME", "Acme Logistics")
COMPANY_MC = os.getenv("COMPANY_MC", "MC 000000")
MODEL_PROVIDER = os.getenv("PAUL_MODEL_PROVIDER", "openai")
MODEL = os.getenv("PAUL_MODEL", "gpt-4o")

PROMPTS_DIR = Path(__file__).resolve().parent.parent / "prompts"


def load_prompt(name: str) -> str:
    text = (PROMPTS_DIR / name).read_text()
    return (
        text.replace("{{company_name}}", COMPANY_NAME)
            .replace("{{company_mc}}", COMPANY_MC)
            .replace("{{dispatch_email}}", os.getenv("DISPATCH_EMAIL", "dispatch@example.com"))
    )


def tool(name: str, description: str, properties: dict, required: list) -> dict:
    return {
        "type": "function",
        "function": {
            "name": name,
            "description": description,
            "parameters": {
                "type": "object",
                "properties": properties,
                "required": required,
            },
        },
        "server": {"url": f"{SERVER_URL}/webhook"},
    }


def create_assistant(config: dict) -> str:
    if not API_KEY:
        raise SystemExit("Set VAPI_API_KEY in .env first. Paul cannot think without it.")
    if not SERVER_URL:
        raise SystemExit("Set SERVER_URL in .env first. Paul needs his brain online.")
    resp = requests.post(
        f"{VAPI_BASE}/assistant",
        headers={"Authorization": f"Bearer {API_KEY}"},
        json=config,
        timeout=30,
    )
    if resp.status_code >= 300:
        raise SystemExit(f"Vapi said no ({resp.status_code}): {resp.text}")
    assistant_id = resp.json().get("id")
    print(f"Created assistant: {assistant_id}")
    print("Paste this ID into your .env file.")
    return assistant_id


def base_assistant(name: str, first_message: str, prompt: str, tools: list) -> dict:
    return {
        "name": name,
        "firstMessage": first_message,
        "model": {
            "provider": MODEL_PROVIDER,
            "model": MODEL,
            "temperature": 0.4,
            "messages": [{"role": "system", "content": prompt}],
            "tools": tools,
        },
        "voice": {"provider": "vapi", "voiceId": "Elliot"},
        "transcriber": {"provider": "deepgram", "model": "nova-2", "language": "en"},
        "server": {"url": f"{SERVER_URL}/webhook"},
        "endCallFunctionEnabled": True,
        "maxDurationSeconds": 300,
        "silenceTimeoutSeconds": 20,
    }

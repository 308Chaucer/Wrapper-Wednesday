"""
Wrapper Paul webhook server.

This is the part the wrappers charge you for. It receives tool calls from
Vapi while Paul is on the phone, answers them from your load board and truck
list, and writes bookings to disk. Swap the JSON files for your TMS and this
becomes the only genuinely proprietary layer in the whole stack. Yours.

Run:  uvicorn src.server:app --host 0.0.0.0 --port 8000
Then expose it publicly (ngrok http 8000) and put that URL in .env as SERVER_URL.

Note: Vapi's webhook payload shapes evolve. This handles the current
"tool-calls" message format. If a field moves, check docs.vapi.ai and
adjust extract_tool_calls below. That is the whole maintenance burden.
"""

import json
from datetime import datetime, timezone
from pathlib import Path

from fastapi import FastAPI, Request

app = FastAPI(title="Wrapper Paul Brain")

DATA_DIR = Path(__file__).resolve().parent.parent / "data"
LOADS_FILE = DATA_DIR / "loads.json"
TRUCKS_FILE = DATA_DIR / "trucks.json"
BOOKINGS_FILE = DATA_DIR / "bookings.json"
CALL_LOG_FILE = DATA_DIR / "call_log.json"


def read_json(path: Path, default):
    if path.exists():
        return json.loads(path.read_text())
    return default


def append_json(path: Path, record: dict):
    records = read_json(path, [])
    record["logged_at"] = datetime.now(timezone.utc).isoformat()
    records.append(record)
    path.write_text(json.dumps(records, indent=2))


# ---------------------------------------------------------------------------
# The tools Paul can use mid call
# ---------------------------------------------------------------------------

def get_load_details(args: dict) -> str:
    loads = read_json(LOADS_FILE, {})
    load = loads.get(args.get("load_id", ""))
    if not load:
        return "No load found with that ID."
    return json.dumps(load)


def get_trucks(args: dict) -> str:
    trucks = read_json(TRUCKS_FILE, {})
    equipment = (args.get("equipment") or "").lower()
    matches = [
        t for t in trucks.values()
        if not equipment or equipment in t["equipment"].lower()
    ]
    if not matches:
        return "No trucks available matching that equipment."
    return json.dumps(matches)


def log_offer(args: dict) -> str:
    append_json(CALL_LOG_FILE, {"type": "offer", **args})
    return "Offer logged."


def log_inquiry(args: dict) -> str:
    append_json(CALL_LOG_FILE, {"type": "inquiry", **args})
    return "Inquiry logged."


def log_checkin(args: dict) -> str:
    append_json(CALL_LOG_FILE, {"type": "checkin", **args})
    return "Check call logged."


def book_carrier(args: dict) -> str:
    append_json(BOOKINGS_FILE, {"type": "carrier_booked", **args})
    return "Booked. Tell them the rate confirmation is on its way."


def book_load(args: dict) -> str:
    append_json(BOOKINGS_FILE, {"type": "load_booked", **args})
    return "Booked. Ask them to send the rate confirmation to dispatch."


TOOLS = {
    "get_load_details": get_load_details,
    "get_trucks": get_trucks,
    "log_offer": log_offer,
    "log_inquiry": log_inquiry,
    "log_checkin": log_checkin,
    "book_carrier": book_carrier,
    "book_load": book_load,
}


# ---------------------------------------------------------------------------
# Webhook plumbing
# ---------------------------------------------------------------------------

def extract_tool_calls(message: dict) -> list:
    """Normalize Vapi's tool call payload into (id, name, args) tuples."""
    calls = []
    for tc in message.get("toolCallList", []) or message.get("toolCalls", []):
        fn = tc.get("function", {})
        args = fn.get("arguments", {})
        if isinstance(args, str):
            try:
                args = json.loads(args)
            except json.JSONDecodeError:
                args = {}
        calls.append((tc.get("id"), fn.get("name"), args))
    return calls


@app.post("/webhook")
async def webhook(request: Request):
    payload = await request.json()
    message = payload.get("message", {})
    msg_type = message.get("type", "")

    if msg_type in ("tool-calls", "function-call"):
        results = []
        for call_id, name, args in extract_tool_calls(message):
            handler = TOOLS.get(name)
            result = handler(args) if handler else f"Unknown tool: {name}"
            results.append({"toolCallId": call_id, "result": result})
        return {"results": results}

    if msg_type == "end-of-call-report":
        append_json(CALL_LOG_FILE, {
            "type": "end_of_call",
            "summary": message.get("analysis", {}).get("summary", ""),
            "ended_reason": message.get("endedReason", ""),
        })
        return {"ok": True}

    # Status updates, transcripts, and anything else: acknowledge and move on.
    return {"ok": True}


@app.get("/")
async def health():
    return {"status": "Paul is thinking", "tools": list(TOOLS.keys())}

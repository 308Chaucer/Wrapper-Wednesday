"""
Create Broker Paul: the outbound capacity sourcing agent.

Run once:  python src/create_broker_paul.py
Then put the printed assistant ID in .env as BROKER_PAUL_ASSISTANT_ID.
"""

from vapi_common import base_assistant, create_assistant, load_prompt, tool, COMPANY_NAME

TOOLS = [
    tool(
        "get_load_details",
        "Look up full details for a load by its load ID.",
        {"load_id": {"type": "string", "description": "The load ID, for example L1001"}},
        ["load_id"],
    ),
    tool(
        "log_offer",
        "Log a carrier's response: their best rate offer, no truck available, or a do not call request.",
        {
            "load_id": {"type": "string"},
            "carrier_name": {"type": "string"},
            "mc_number": {"type": "string"},
            "best_offer": {"type": "number", "description": "Their best all in rate in dollars, 0 if none"},
            "note": {"type": "string"},
        },
        ["load_id", "note"],
    ),
    tool(
        "log_checkin",
        "Log a check call: driver location, schedule status, ETA, and reefer temperature if applicable.",
        {
            "load_id": {"type": "string"},
            "location": {"type": "string"},
            "on_schedule": {"type": "boolean"},
            "eta": {"type": "string"},
            "reefer_temp": {"type": "string"},
            "exception": {"type": "string", "description": "Describe any problem, empty if none"},
        },
        ["load_id", "location", "on_schedule"],
    ),
    tool(
        "book_carrier",
        "Book the carrier on the load once all details are confirmed and the rate is at or below the ceiling.",
        {
            "load_id": {"type": "string"},
            "carrier_name": {"type": "string"},
            "mc_number": {"type": "string"},
            "agreed_rate": {"type": "number"},
            "driver_name": {"type": "string"},
            "driver_cell": {"type": "string"},
            "email": {"type": "string"},
        },
        ["load_id", "carrier_name", "mc_number", "agreed_rate", "driver_name", "driver_cell", "email"],
    ),
]

if __name__ == "__main__":
    config = base_assistant(
        name="Broker Paul",
        first_message=(
            f"Hi, this is Paul, an automated assistant calling for {COMPANY_NAME}. "
            "I'm calling about a load. Do you have a quick minute?"
        ),
        prompt=load_prompt("broker_paul.md"),
        tools=TOOLS,
    )
    create_assistant(config)

"""
Create Carrier Paul: the inbound dispatch assistant for carriers.

Run once:  python src/create_carrier_paul.py
Then put the printed assistant ID in .env as CARRIER_PAUL_ASSISTANT_ID
and assign it to your inbound number in the Vapi dashboard
(Phone Numbers, select your number, set Assistant).
"""

from vapi_common import base_assistant, create_assistant, load_prompt, tool, COMPANY_NAME

TOOLS = [
    tool(
        "get_trucks",
        "Check available trucks, optionally filtered by equipment type such as dry van, reefer, or flatbed.",
        {"equipment": {"type": "string", "description": "Equipment type to filter by, optional"}},
        [],
    ),
    tool(
        "log_inquiry",
        "Log a broker inquiry that did not result in a booking, including the lane and any offered rate.",
        {
            "broker_name": {"type": "string"},
            "lane": {"type": "string", "description": "Origin to destination"},
            "equipment": {"type": "string"},
            "offered_rate": {"type": "number", "description": "Their offer in dollars, 0 if none"},
            "note": {"type": "string"},
        },
        ["lane", "note"],
    ),
    tool(
        "book_load",
        "Book a load onto one of our trucks once all details are confirmed and the rate is at or above the floor.",
        {
            "truck_id": {"type": "string"},
            "broker_name": {"type": "string"},
            "broker_mc": {"type": "string"},
            "load_number": {"type": "string"},
            "pickup": {"type": "string", "description": "City, state, and date"},
            "delivery": {"type": "string", "description": "City, state, and date"},
            "agreed_rate": {"type": "number"},
        },
        ["truck_id", "broker_name", "broker_mc", "pickup", "delivery", "agreed_rate"],
    ),
]

if __name__ == "__main__":
    config = base_assistant(
        name="Carrier Paul",
        first_message=(
            f"Thanks for calling {COMPANY_NAME}. This is Paul, the automated dispatch assistant. "
            "Are you calling about a load?"
        ),
        prompt=load_prompt("carrier_paul.md"),
        tools=TOOLS,
    )
    create_assistant(config)

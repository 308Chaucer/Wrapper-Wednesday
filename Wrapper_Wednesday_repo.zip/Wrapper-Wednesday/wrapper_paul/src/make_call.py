"""
Point Broker Paul at a carrier.

Usage:
    python src/make_call.py --load L1001 --to +15551234567

Paul pulls the load from data/loads.json, dials the carrier, negotiates
inside your ceiling, and books through the webhook server if they agree.
"""

import argparse
import json
import os
from pathlib import Path

import requests
from dotenv import load_dotenv

load_dotenv()

VAPI_BASE = "https://api.vapi.ai"
DATA_DIR = Path(__file__).resolve().parent.parent / "data"


def main():
    parser = argparse.ArgumentParser(description="Send Broker Paul to cover a load.")
    parser.add_argument("--load", required=True, help="Load ID from data/loads.json, e.g. L1001")
    parser.add_argument("--to", required=True, help="Carrier phone number in E.164 format, e.g. +15551234567")
    parser.add_argument("--checkin", action="store_true", help="Make this a check call instead of a coverage call")
    args = parser.parse_args()

    api_key = os.getenv("VAPI_API_KEY", "")
    phone_number_id = os.getenv("VAPI_PHONE_NUMBER_ID", "")
    assistant_id = os.getenv("BROKER_PAUL_ASSISTANT_ID", "")
    if not all([api_key, phone_number_id, assistant_id]):
        raise SystemExit("Fill in VAPI_API_KEY, VAPI_PHONE_NUMBER_ID, and BROKER_PAUL_ASSISTANT_ID in .env first.")

    loads = json.loads((DATA_DIR / "loads.json").read_text())
    load = loads.get(args.load)
    if not load:
        raise SystemExit(f"Load {args.load} not found in data/loads.json")

    variables = {k: str(v) for k, v in load.items()}
    variables["call_type"] = "checkin" if args.checkin else "coverage"

    resp = requests.post(
        f"{VAPI_BASE}/call",
        headers={"Authorization": f"Bearer {api_key}"},
        json={
            "assistantId": assistant_id,
            "phoneNumberId": phone_number_id,
            "customer": {"number": args.to},
            "assistantOverrides": {"variableValues": variables},
        },
        timeout=30,
    )
    if resp.status_code >= 300:
        raise SystemExit(f"Vapi said no ({resp.status_code}): {resp.text}")

    call = resp.json()
    print(f"Paul is dialing. Call ID: {call.get('id')}")
    print("Watch data/bookings.json and data/call_log.json for the outcome.")


if __name__ == "__main__":
    main()

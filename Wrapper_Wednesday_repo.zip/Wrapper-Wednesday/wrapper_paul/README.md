# Wrapper Paul

A voice AI agent for freight, recreated from the same publicly available stack FleetWorks is built on. Paul makes and takes freight calls. Paul negotiates inside the guardrails you set. Paul tells the truth when a carrier asks if he is a robot, which puts him ahead of several funded competitors.

Two configurations ship in this folder:

- **Broker Paul** (outbound): sources capacity on open loads, negotiates rates up to your ceiling, runs check calls, books carriers.
- **Carrier Paul** (inbound): answers broker calls, quotes available trucks, negotiates down to your floor, books loads.

## The stack

| Layer | Tool | Monthly cost, roughly |
|-------|------|----------------------|
| Voice agent platform | [Vapi](https://vapi.ai) | Usage based, about $0.05 to $0.15 per minute all in |
| Phone number | Twilio (or buy the number inside Vapi) | About $1.15 per number |
| Model | GPT 4o, Claude, or your choice inside Vapi | Included in per minute pricing |
| Your business logic | The webhook server in `/src` | Free. You own it. |

That is the entire bill of materials. There is no step five.

## Setup (one afternoon)

### 1. Accounts

1. Create a [Vapi](https://vapi.ai) account and grab your API key from the dashboard.
2. Buy a phone number. Easiest path is inside Vapi (Phone Numbers, Buy Number). Copy the phone number ID.
3. You will need a public URL for the webhook server. For testing, [ngrok](https://ngrok.com) works: `ngrok http 8000`.

### 2. Install

```bash
cd wrapper_paul
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
```

Fill in `.env` with your Vapi API key, phone number ID, server URL, and company details.

### 3. Start the brain

```bash
uvicorn src.server:app --host 0.0.0.0 --port 8000
```

This serves your load board (`data/loads.json`), your truck list (`data/trucks.json`), and receives Paul's tool calls: looking up loads, logging offers, booking carriers. Edit the JSON files to reflect your actual freight, or wire the server into your TMS. That part is your proprietary edge. Congratulations, you now have more proprietary technology than the companies covered in this series.

### 4. Create Paul

```bash
python src/create_broker_paul.py     # outbound agent for brokers
python src/create_carrier_paul.py    # inbound agent for carriers
```

Each script prints an assistant ID. Save them in `.env`.

For Carrier Paul, assign the assistant to your inbound number in the Vapi dashboard (Phone Numbers, select number, set Assistant). Brokers who call that number now talk to Paul.

### 5. Make Broker Paul work

```bash
python src/make_call.py --load L1001 --to +15551234567
```

Broker Paul calls the carrier, pitches the load, negotiates inside your ceiling, and books it through your webhook if they agree. The booking lands in `data/bookings.json` with the agreed rate and the MC number.

## Tuning Paul

The prompts live in `/prompts` in plain English. They were written by people who have covered a load at 4pm on a Friday, and they encode the things that matter: confirm the MC number, never quote past the guardrail, get a driver name and cell before you call it booked, keep the call under four minutes. Change them freely. Prompt engineering is not a moat, but it is a fine hobby.

## Compliance, seriously

Paul discloses that he is an automated assistant at the start of every call and this is not optional. Automated outbound calling is regulated (TCPA in the United States) and call recording consent laws vary by state. Business to business calling to carriers you have a relationship with is the normal use case here, but you are responsible for your own compliance. Talk to your attorney before you unleash Paul on strangers. Paul would want it that way.

## What Paul does not do

Paul does not have a Series A. Paul does not have a sales team. Paul does not have a party budget. Paul is a config file with a work ethic, and the config file is yours.

Own the agent, don't become one.
